
        const KERNEL_INSTALLER_PATH: &str = "/Users/huanchengchang/code/jstz/target/debug/build/jstzd-36899dff63513454/out/kernel_installer.hex";

        pub fn kernel_installer_path() -> std::path::PathBuf {
            let path = std::path::PathBuf::from(KERNEL_INSTALLER_PATH);
            if path.exists() {
                path
            } else {
                std::path::PathBuf::from("/usr/share/jstz/kernel_installer.hex")
            }
        }
        
        const PARAMETERS_TY_PATH: &str = "/Users/huanchengchang/code/jstz/target/debug/build/jstzd-36899dff63513454/out/parameters_ty.json";

        pub fn parameters_ty_path() -> std::path::PathBuf {
            let path = std::path::PathBuf::from(PARAMETERS_TY_PATH);
            if path.exists() {
                path
            } else {
                std::path::PathBuf::from("/usr/share/jstz/parameters_ty.json")
            }
        }
        
        const PREIMAGES_PATH: &str = "/Users/huanchengchang/code/jstz/target/debug/build/jstzd-36899dff63513454/out/preimages";

        pub fn preimages_path() -> std::path::PathBuf {
            let path = std::path::PathBuf::from(PREIMAGES_PATH);
            if path.exists() {
                path
            } else {
                std::path::PathBuf::from("/usr/share/jstz/preimages")
            }
        }
        